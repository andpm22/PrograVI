﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProyectoFinalSistemaReservaciones.Models;
namespace ProyectoFinalSistemaReservaciones.Filters
{
    public class VerificarSesionFilters : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var sesion = (PersonaModel)HttpContext.Current.Session["usuario"];
            if (sesion == null)
            {
                filterContext.HttpContext.Response.Redirect("~/Reservaciones/Autenticacion");
            }
            base.OnActionExecuting(filterContext);
        }
    }
}