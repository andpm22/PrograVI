﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProyectoFinalSistemaReservaciones.Models;
using ProyectoFinalSistemaReservaciones.Data;
using ProyectoFinalSistemaReservaciones.Filters;

namespace ProyectoFinalSistemaReservaciones.Controllers
{
    public class ReservacionesController : Controller
    {
        // GET: Reservaciones

        //Aqui cargo la pantalla para loguearme
        [HttpGet]
        public ActionResult Autenticacion()
        {
            //Este condicional ayuda a una sesion vigente a no redireccionar a la pantalla de logueo
            //Me permite redireccionar al listado correcto dependiendo del usuario
            PersonaModel sesion = (PersonaModel)Session["usuario"];
            if (sesion != null)
            {
                if (sesion.esEmpleado == true)
                {
                    return RedirectToAction("ReservacionesGlobales", "Reservaciones");
                }
                else
                {
                    return RedirectToAction("MisReservaciones", "Reservaciones");
                }
            }
            return View("PantallaAutenticacion");
        }

        //Aqui verifico que exista el usuario y si es empleado o no
        [HttpPost]
        public ActionResult Autenticacion(PersonaModel persona)
        {
            PersonaModel personaDatos = null;
            try
            {
                if (!ModelState.IsValid)
                {
                    return View("PantallaAutenticacion", persona);
                }
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    personaDatos = (from p in db.spAutenticar(persona.email, persona.clave)
                                    select new PersonaModel
                                    {
                                        idPersona = p.idPersona,
                                        nombreCompleto = p.nombreCompleto,
                                        esEmpleado = p.esEmpleado
                                    }).FirstOrDefault();

                    Session["usuario"] = personaDatos;



                }
                PersonaModel sesion = (PersonaModel)Session["usuario"];
                if (sesion.esEmpleado == true)
                {
                    return RedirectToAction("ReservacionesGlobales", "Reservaciones");
                }
                else
                {
                    return RedirectToAction("MisReservaciones", "Reservaciones");
                }


            }

            catch
            {
                //Si los datos a la hora de usar el sp retornan null entonces muestro el siguiente mentsaje
                if (personaDatos == null)
                {
                    ViewBag.error = "El correo o contraseña son inválidos";
                }
                return View("PantallaAutenticacion");
            }

        }

        //Con esta acción estoy mostrando la lista de reservaciones globales para un empleado
        [HttpGet]
        [VerificarSesionFilters]
        public ActionResult ReservacionesGlobales()
        {
            try
            {
                PersonaModel sesion = (PersonaModel)Session["usuario"];
                if (sesion == null)
                {
                    return RedirectToAction("Autenticacion", "Reservaciones");
                }
                if (sesion.esEmpleado == false)
                {
                    return RedirectToAction("MisReservaciones", "Reservaciones");
                }
                //Consigo los datos para el DDL
                List<GestionarReservacionesModel> listaPlataformas = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    listaPlataformas = (from p in db.spDropDownFiltroCliente()
                                        select new GestionarReservacionesModel
                                        {
                                            idPersona = p.idPersona,
                                            nombreCompleto = p.nombreCompleto
                                        }).ToList();
                }
                //Asigno la lista a una variable de sesion para que no se pierda en el POST
                Session["listaPlataformas"] = listaPlataformas;
                ViewBag.clientes = listaPlataformas;

                List<GestionarReservacionesModel> listaReservaciones = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    listaReservaciones = (from r in db.spGestionarTodasLasReservaciones()
                                          select new GestionarReservacionesModel
                                          {
                                              idReservacion = r.idReservacion,
                                              nombreCompleto = r.nombreCompleto,
                                              nombreHotel = r.nombre,
                                              fechaEntrada = r.fechaEntrada,
                                              fechaSalida = r.fechaSalida,
                                              costoTotal = r.costoTotal,
                                              estado = r.estado,
                                              idPersona = r.idPersona
                                          }).ToList();
                }
                //DateTime fechaHoy = DateTime.Now;
                //foreach (var lista in listaReservaciones)
                //{

                //    if (lista.estado == "I")
                //    {
                //        lista.estado = "Cancelada";
                //    }
                //    if (lista.estado == "A" && lista.fechaSalida < fechaHoy)
                //    {
                //        lista.estado = "Finalizada";
                //    }
                //    if (lista.estado == "A" && lista.fechaEntrada <= fechaHoy)
                //    {
                //        lista.estado = "En proceso";
                //    }
                //    if (lista.estado == "A" && lista.fechaEntrada > fechaHoy && lista.fechaSalida > fechaHoy)
                //    {
                //        lista.estado = "En espera";
                //    }
                //}
                foreach (var lista in listaReservaciones)
                {
                    lista.estado = lista.estadosTraducidos;
                }

                ViewBag.query = listaReservaciones;
                return View("ReservacionesGlobales");
            }

            catch
            {
                return View("Error");
            }
        }

        //Con esta accion se puede realizar la busqueda mediante el nombre del cliente
        [HttpPost]
        public ActionResult Buscar(GestionarReservacionesModel filtro)
        {
            try
            {
                ViewBag.clientes = Session["listaPlataformas"];
                ViewBag.query = "";
                //Aparece si faltan todos los parametros
                if (filtro.idPersona == null && filtro.fechaEntrada == null && filtro.fechaSalida == null)
                {
                    ViewBag.mensajeFiltro = "No se seleccionaron parametros en su busqueda datos";
                }
                //Aparece si falta algun parametro
                if (filtro.idPersona == null && (filtro.fechaEntrada == null || filtro.fechaSalida == null))
                {
                    ViewBag.mensajeFiltro = "Faltan parametros para realizar su busqueda";
                }
                //Realiza la busqueda con todos los paramatros
                if (filtro.idPersona != 0 && filtro.fechaEntrada != null && filtro.fechaSalida != null)
                {
                    if (filtro.fechaSalida >= filtro.fechaEntrada && filtro.idPersona != null)
                    {
                        List<GestionarReservacionesModel> listaFiltrada = null;
                        using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                        {
                            listaFiltrada = (from r in db.spFiltroUsandoFullParametros(filtro.idPersona, filtro.fechaSalida, filtro.fechaEntrada)
                                             select new GestionarReservacionesModel
                                             {
                                                 idReservacion = r.idReservacion,
                                                 nombreCompleto = r.nombreCompleto,
                                                 nombreHotel = r.nombre,
                                                 fechaEntrada = r.fechaEntrada,
                                                 fechaSalida = r.fechaSalida,
                                                 costoTotal = r.costoTotal,
                                                 estado = r.estado
                                             }).ToList();
                            foreach (var lista in listaFiltrada)
                            {
                                lista.estado = lista.estadosTraducidos;
                            }
                        }

                        ViewBag.query = listaFiltrada;
                        return View("ReservacionesGlobales");
                    }
                    if (filtro.fechaSalida < filtro.fechaEntrada && filtro.idPersona == null)
                    {
                        ViewBag.mensajeFiltro = " La fecha de salida debe ser mayor o igual a la fecha de entrada";
                    }

                }
                //Realiza la busqueda solo con el nombre de la persona
                if (filtro.idPersona != null)
                {
                    ViewBag.clientes = Session["listaPlataformas"];
                    List<GestionarReservacionesModel> listaFiltrada = null;
                    using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                    {
                        listaFiltrada = (from r in db.spFiltroUsandoIdClientes(filtro.idPersona)
                                         select new GestionarReservacionesModel
                                         {
                                             idReservacion = r.idReservacion,
                                             nombreCompleto = r.nombreCompleto,
                                             nombreHotel = r.nombre,
                                             fechaEntrada = r.fechaEntrada,
                                             fechaSalida = r.fechaSalida,
                                             costoTotal = r.costoTotal,
                                             estado = r.estado
                                         }).ToList();
                        foreach (var lista in listaFiltrada)
                        {
                            lista.estado = lista.estadosTraducidos;
                        }
                    }

                    ViewBag.query = listaFiltrada;
                    return View("ReservacionesGlobales");
                }
                //Realiza la busqueda solo con las fechas
                if (filtro.fechaEntrada != null && filtro.fechaSalida != null)
                {
                    //Permite realizar el filtro si la fecha de salida es mayor o igual a la de entrada
                    if (filtro.fechaSalida >= filtro.fechaEntrada)
                    {
                        List<GestionarReservacionesModel> listaFiltrada = null;
                        using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                        {
                            listaFiltrada = (from r in db.spFiltroUsandoFechas(filtro.fechaSalida, filtro.fechaEntrada)
                                             select new GestionarReservacionesModel
                                             {
                                                 idReservacion = r.idReservacion,
                                                 nombreCompleto = r.nombreCompleto,
                                                 nombreHotel = r.nombre,
                                                 fechaEntrada = r.fechaEntrada,
                                                 fechaSalida = r.fechaSalida,
                                                 costoTotal = r.costoTotal,
                                                 estado = r.estado
                                             }).ToList();
                            foreach (var lista in listaFiltrada)
                            {
                                lista.estado = lista.estadosTraducidos;
                            }
                        }
                        ViewBag.query = listaFiltrada;
                        return View("ReservacionesGlobales");
                    }
                    else
                    {
                        ViewBag.mensajeFiltro = "La fecha de salida debe ser mayor o igual a la fecha de entrada";
                    }
                }
                return View("ReservacionesGlobales");
            }

            catch
            {
                return View("Error");
            }
        }

        //Con esta acción se quiere mostrar las reservaciones de un cliente
        [HttpGet]
        [VerificarSesionFilters]
        public ActionResult MisReservaciones()
        {
            try
            {
                PersonaModel sesion = (PersonaModel)Session["usuario"];

                if (sesion == null)
                {
                    return View("PantallaAutenticacion");
                }
                List<GestionarReservacionesModel> listaReservaciones = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    listaReservaciones = (from r in db.spGestionarMisReservaciones(sesion.idPersona)
                                          select new GestionarReservacionesModel
                                          {
                                              idReservacion = r.idReservacion,
                                              nombreHotel = r.nombre,
                                              fechaEntrada = r.fechaEntrada,
                                              fechaSalida = r.fechaSalida,
                                              costoTotal = r.costoTotal,
                                              estado = r.estado
                                          }).ToList();
                }

                foreach (var lista in listaReservaciones)
                {
                    lista.estado = lista.estadosTraducidos;
                }

                ViewBag.query = listaReservaciones;
                return View("MisReservaciones");
            }

            catch
            {
                return View("Error");
            }
        }

        //Aca puedo ver los detalles de una reservacion
        [HttpGet]
        [VerificarSesionFilters]
        public ActionResult Detalle(int idReservacion)
        {
            try
            {
                // Traigo los datos relacionados a una reservacion
                PersonaModel sesion = (PersonaModel)Session["usuario"];
                DetalleReservacion reservacion = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    reservacion = (from r in db.spDetalleReservaciones(idReservacion)
                                   select new DetalleReservacion
                                   {
                                       idReservacion = r.idReservacion,
                                       nombreHotel = r.nombre,
                                       numeroHabitacion = r.numeroHabitacion,
                                       nombreCompleto = r.nombreCompleto,
                                       fechaEntrada = r.fechaEntrada,
                                       fechaSalida = r.fechaSalida,
                                       numeroAdultos = r.numeroAdultos,
                                       numeroNinhos = r.numeroNinhos,
                                       costoTotal = r.costoTotal,
                                       esEmpleado = sesion.esEmpleado,
                                       estado = r.estado

                                   }).FirstOrDefault();
                }

                // Traigo los datos relacionados a la bitacora de una reservacion
                List<BitacoraModel> listaBitacoras = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    listaBitacoras = (from b in db.spBitacoraReservacion(idReservacion)
                                      select new BitacoraModel
                                      {
                                          fechaDeLaAccion = b.fechaDeLaAccion,
                                          accionRealizada = b.accionRealizada,
                                          nombreCompleto = b.nombreCompleto
                                      }).ToList();
                }
                ViewBag.bitacora = listaBitacoras;

                //Devuelvo a los usuarios maliciosos
                if (sesion.esEmpleado == false && sesion.nombreCompleto != reservacion.nombreCompleto) 
                {
                    return RedirectToAction("Retornar", "Reservaciones");
                }

                return View("DetalleReservacion", reservacion);
            }

            catch
            {
                return View("Error");
            }
        }

        //Decido a cual menu retornar al usuario
        [HttpGet]
        public ActionResult Retornar()
        {
            try
            {
                PersonaModel sesion = (PersonaModel)Session["usuario"];
                if (sesion.esEmpleado == true)
                {
                    return RedirectToAction("ReservacionesGlobales", "Reservaciones");
                }
                else
                {
                    return RedirectToAction("MisReservaciones", "Reservaciones");
                }
            }
            catch
            {
                return View("Error");
            }
        }

        //Cargo la pagina de crear reservacion
        [HttpGet]
        [VerificarSesionFilters]
        public ActionResult Crear()
        {
            try
            {
                PersonaModel sesion = (PersonaModel)Session["usuario"];
                if (sesion == null)
                {
                    return View("PantallaAutenticacion");
                }
                ViewBag.esEmpleado = sesion.esEmpleado;

                //Consigo los datos para el DDL del Cliente
                List<GestionarReservacionesModel> listaClientes = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    listaClientes = (from p in db.spDropDownFiltroCliente()
                                     select new GestionarReservacionesModel
                                     {
                                         idPersona = p.idPersona,
                                         nombreCompleto = p.nombreCompleto
                                     }).ToList();
                }
                //Asigno la lista a una variable de sesion para que no se pierda en el POST
                Session["listaClientes"] = listaClientes;
                ViewBag.clientes = listaClientes;
                //Consigo los datos para el DDL de los Hoteles
                List<GestionarReservacionesModel> listaHoteles = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    listaHoteles = (from h in db.spDropDownHotel()
                                    select new GestionarReservacionesModel
                                    {
                                        idHotel = h.idHotel,
                                        nombreHotel = h.nombre
                                    }).ToList();
                }
                //Asigno la lista a una variable de sesion para que no se pierda en el POST
                Session["listaHoteles"] = listaHoteles;
                ViewBag.hoteles = listaHoteles;

                //Aqui paso los datos para una persona que no es laborador
                if (sesion.esEmpleado == false)
                {
                    List<GestionarReservacionesModel> datosUsuario = new List<GestionarReservacionesModel>
                    {
                        new GestionarReservacionesModel {idPersona = sesion.idPersona ,nombreCompleto = sesion.nombreCompleto}


                    };
                    ViewBag.personaNoEmpleado = datosUsuario;
                    return View("CrearReservacion");

                    //List<SelectListItem> objeto = datosUsuario.ConvertAll(m => 
                    //{
                    //    return new SelectListItem()
                    //    {
                    //        Text = m.nombreCompleto,
                    //        Value = m.idPersona.ToString(),
                    //        Selected = true

                    //    };

                    //});
                    //ViewBag.clientes = objeto
                }

                return View("CrearReservacion");
            }
            catch
            {
                return View("Error");
            }
        }

        //Accion Post de crear una reservacion
        [HttpPost]
        [VerificarSesionFilters]
        public ActionResult Crear(GestionarReservacionesModel reservacion)
        {
            try
            {
                PersonaModel sesion = (PersonaModel)Session["usuario"];

                if (sesion == null)
                {
                    return View("PantallaAutenticacion");
                }
                ViewBag.esEmpleado = sesion.esEmpleado;
                //Lleno los DDL nuevamente para el Post       
                ViewBag.clientes = Session["listaClientes"];
                ViewBag.hoteles = Session["listaHoteles"];
                if (sesion.esEmpleado == false)
                {
                    List<GestionarReservacionesModel> datosUsuario = new List<GestionarReservacionesModel>
                    {
                        new GestionarReservacionesModel {idPersona = sesion.idPersona ,nombreCompleto = sesion.nombreCompleto}


                    };
                    ViewBag.personaNoEmpleado = datosUsuario;

                }

                if (!ModelState.IsValid)
                {

                    return View("CrearReservacion", reservacion);
                }
                //Algoritmo que me trae las habitaciones con menos reservaciones
                List<HabitacionModel> habitacion = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    habitacion = (from h in db.spCalcularHabitacionDeHotel(reservacion.idHotel)
                                  select new HabitacionModel
                                  {
                                      idHabitacion = h.idHabitacion,
                                      capacidadMaxima = h.capacidadMaxima
                                  }).ToList();
                }




                if (reservacion.fechaEntrada > DateTime.Now && reservacion.fechaSalida >= reservacion.fechaEntrada)
                {
                    int totalPersonas = reservacion.numeroAdultos + reservacion.numeroNinhos;

                    Boolean habitacionCantidadDisponible = false;
                    Boolean habitacionFechasDisponible = true;
                    int idHabitacion = 0;
                    int capacidadMaxima = 0;
                    //Valido que exista una habitacion disponible
                    foreach (var habitacionReservar in habitacion)
                    {
                        if (totalPersonas <= habitacionReservar.capacidadMaxima)
                        {
                            idHabitacion = habitacionReservar.idHabitacion;
                            capacidadMaxima = habitacionReservar.capacidadMaxima;
                            habitacionCantidadDisponible = true;
                            break;
                        }
                    }
                    //Si hay habitaciones disponibles obtengo las fechas de las habitaciones para ver si no estan registradas
                    if (habitacionCantidadDisponible == true)
                    {
                        List<GestionarReservacionesModel> habitacionReservada = null;
                        using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                        {
                            habitacionReservada = (from h in db.spFechasDeHabitaciones(idHabitacion)
                                                   select new GestionarReservacionesModel
                                                   {
                                                       fechaEntrada = h.fechaEntrada,
                                                       fechaSalida = h.fechaSalida
                                                   }).ToList();
                        }

                        //Valido las fechas de la habitacion
                        foreach (var datosHabitacion in habitacionReservada)
                        {
                            //Si me meto aca es porque las fechas chochan
                            if ((reservacion.fechaEntrada >= datosHabitacion.fechaEntrada && reservacion.fechaEntrada <= datosHabitacion.fechaSalida) || (reservacion.fechaSalida >= datosHabitacion.fechaEntrada && reservacion.fechaSalida <= datosHabitacion.fechaSalida))
                            {
                                //No se puede realizar en esa fecha el registro
                                habitacionFechasDisponible = false;
                                ViewBag.aviso = "La habitación tiene una fecha para ese día";
                                break;
                            }
                        }
                    }
                    if (habitacionCantidadDisponible == false)
                    {
                        ViewBag.aviso = "Su cantidad de personas excede la cantidad máxima de las habitaciones disponibles";
                    }
                    // Si todo esta bien proceso con salvar la reservacion
                    if (habitacionFechasDisponible == true && habitacionCantidadDisponible == true)
                    {

                        HotelModel habitacionReservada = null;
                        using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                        {
                            habitacionReservada = (from h in db.spDatosDeUnHotel(reservacion.idHotel)
                                                   select new HotelModel
                                                   {
                                                       costoPorCadaAdulto = h.costoPorCadaAdulto,
                                                       costoPorCadaNinho = h.costoPorCadaNinho,
                                                   }).FirstOrDefault();

                        }

                        //Aqui hago los calculos
                        TimeSpan totalDias = (TimeSpan)(reservacion.fechaSalida - reservacion.fechaEntrada);
                        int totalDiasEnEntero = int.Parse(totalDias.Days.ToString());
                        if (totalDiasEnEntero == 0)
                        {
                            totalDiasEnEntero = 1;
                        }
                        decimal montoTotal = totalDiasEnEntero * ((reservacion.numeroAdultos * habitacionReservada.costoPorCadaAdulto) + (reservacion.numeroNinhos * habitacionReservada.costoPorCadaNinho));
                        if (reservacion.numeroAdultos <= capacidadMaxima && reservacion.numeroNinhos >= 0)
                        {
                            DateTime fechaCreacion = DateTime.Now;
                            using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                            {
                                db.spInsertarUnaReservacion
                                    (reservacion.idPersona,
                                    sesion.idPersona,
                                    idHabitacion,
                                    reservacion.fechaEntrada,
                                    reservacion.fechaSalida,
                                    reservacion.numeroAdultos,
                                    reservacion.numeroNinhos,
                                    totalDiasEnEntero,
                                    habitacionReservada.costoPorCadaAdulto,
                                    habitacionReservada.costoPorCadaNinho,
                                    montoTotal, fechaCreacion);
                            }
                            ViewBag.difenciador = "Reservacion";
                            ViewBag.aviso = "Se ha registrado con exito su reservación";
                            return View("Mensaje");
                        }



                    }
                }
                else
                {
                    ViewBag.aviso = "Las fechas no son válidas para realizar una reservación";
                }
                return View("CrearReservacion");
            }
            catch
            {
                return View("Error");
            }
        }

        //Aqui cargo la vista para editar
        [HttpGet]
        public ActionResult Editar(int idReservacion)
        {

            try
            {
                PersonaModel sesion = (PersonaModel)Session["usuario"];
                if (sesion == null)
                {
                    return View("PantallaAutenticacion");
                }

                GestionarReservacionesModel infoDeUnaReservacion = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    infoDeUnaReservacion = (from r in db.spMostrarReservacionPorUnUsuario(idReservacion)
                                            select new GestionarReservacionesModel
                                            {
                                                idReservacion = r.idReservacion,
                                                idPersona = r.idPersona,
                                                idHabitacion = r.idHabitacion,
                                                fechaEntrada = r.fechaEntrada,
                                                fechaSalida = r.fechaSalida,
                                                numeroAdultos = r.numeroAdultos,
                                                numeroNinhos = r.numeroNinhos,
                                                totalDiasReservacion = r.totalDiasReservacion,
                                                costoPorCadaAdulto = r.costoPorCadaAdulto,
                                                costoPorCadaNinho = r.costoPorCadaNinho,
                                                costoTotal = r.costoTotal,
                                                fechaCreacion = r.fechaCreacion,
                                                fechaModificacion = r.fechaModificacion,
                                                estado = r.estado,
                                                numeroHabitacion = r.numeroHabitacion,
                                                nombreHotel = r.nombre,
                                                nombreCompleto = r.nombreCompleto,
                                                capacidadHabitacion = r.capacidadMaxima,
                                                idHotel = r.idHotel
                                            }).FirstOrDefault();
                    Session["editarReservacion"] = infoDeUnaReservacion;
                }
                //Aqui no permito actualizar una reservacion con estado I o una reservacion vieja
                if (infoDeUnaReservacion.estado == "I" || infoDeUnaReservacion.fechaSalida <= DateTime.Now)
                {
                    return RedirectToAction("Retornar", "Reservaciones");
                }
                //Aqui no permito actualizar una reservacion en proceso para un usuario
                if (infoDeUnaReservacion.fechaEntrada <= DateTime.Now && infoDeUnaReservacion.fechaSalida > DateTime.Now && sesion.esEmpleado == false)
                {
                    return RedirectToAction("MisReservaciones", "Reservaciones");
                }
                //Aqui no permito actualizar una reservacion que es de otro usuario
                if (sesion.esEmpleado == false && sesion.idPersona != infoDeUnaReservacion.idPersona)
                {
                    return RedirectToAction("MisReservaciones", "Reservaciones");
                }


                return View("Editar", infoDeUnaReservacion);
            }

            catch
            {
                return View("Error");
            }

        }

        //Aqui hago el post para editar
        [HttpPost]
        [VerificarSesionFilters]
        public ActionResult Editar(GestionarReservacionesModel reservacion)
        {
            try
            {
                PersonaModel sesion = (PersonaModel)Session["usuario"];
                if (sesion == null)
                {
                    return View("PantallaAutenticacion");
                }
                
                GestionarReservacionesModel datosAEditar = (GestionarReservacionesModel)Session["editarReservacion"];
                if (!ModelState.IsValid)
                {
                    reservacion = (GestionarReservacionesModel)Session["editarReservacion"];
                    return View("Editar", reservacion);
                }

                if (reservacion.fechaEntrada > DateTime.Today && reservacion.fechaSalida > reservacion.fechaEntrada)
                {
                    int totalPersonas = reservacion.numeroAdultos + reservacion.numeroNinhos;


                    Boolean habitacionCantidadDisponible = false;
                    //Valido la capacidad maxima
                    if (totalPersonas <= datosAEditar.capacidadHabitacion)
                    {
                        habitacionCantidadDisponible = true;
                    }

                    //Si hay habitaciones disponibles obtengo las fechas de las habitaciones para ver si no estan registradas
                    if (habitacionCantidadDisponible == true)
                    {
                        List<GestionarReservacionesModel> habitacionReservada = null;
                        using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                        {
                            habitacionReservada = (from h in db.spFechasDeHabitaciones(datosAEditar.idHabitacion)
                                                   select new GestionarReservacionesModel
                                                   {
                                                       fechaEntrada = h.fechaEntrada,
                                                       fechaSalida = h.fechaSalida
                                                   }).ToList();
                        }
                    }
                    if (habitacionCantidadDisponible == false)
                    {
                        ViewBag.aviso = "Su cantidad de personas excede la cantidad máxima de las habitaciones disponibles";
                    }

                    // Si todo esta bien procedo con salvar la reservacion
                    if (habitacionCantidadDisponible == true)
                    {
                        HotelModel habitacionReservada = null;
                        using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                        {
                            habitacionReservada = (from h in db.spDatosDeUnHotel(datosAEditar.idHotel)
                                                   select new HotelModel
                                                   {
                                                       costoPorCadaAdulto = h.costoPorCadaAdulto,
                                                       costoPorCadaNinho = h.costoPorCadaNinho,
                                                   }).FirstOrDefault();

                        }

                        //Aqui hago los calculos
                        TimeSpan totalDias = (TimeSpan)(reservacion.fechaSalida - reservacion.fechaEntrada);
                        int totalDiasEnEntero = int.Parse(totalDias.Days.ToString());
                        decimal montoTotal = totalDiasEnEntero * ((reservacion.numeroAdultos * habitacionReservada.costoPorCadaAdulto) + (reservacion.numeroNinhos * habitacionReservada.costoPorCadaNinho));
                        if (reservacion.numeroAdultos <= datosAEditar.capacidadHabitacion && reservacion.numeroNinhos >= 0)
                        {
                            DateTime fechaCreacion = DateTime.Now;
                            using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                            {
                                db.spEditarReservacion
                                    (
                                    datosAEditar.idReservacion,
                                    reservacion.fechaEntrada,
                                    reservacion.fechaSalida,
                                    reservacion.numeroAdultos,
                                    reservacion.numeroNinhos,
                                    totalDiasEnEntero,
                                    habitacionReservada.costoPorCadaAdulto,
                                    habitacionReservada.costoPorCadaNinho,
                                    montoTotal,
                                    DateTime.Now,
                                    sesion.idPersona,
                                    DateTime.Now
                                    );
                            }
                            ViewBag.difenciador = "Reservacion";
                            ViewBag.aviso = "Se ha actualizado con exito su reservación";
                            return View("Mensaje");
                        }

                    }
                    else
                    {
                        ViewBag.aviso = "Capacidad máxima excedida en la habitación. No se puede editar su reservación";
                    }
                }
                else
                {
                    ViewBag.aviso = "Las fechas no son válidas para realizar una reservación";
                }
                return View("Editar", datosAEditar);
            }
            catch
            {
                return View("Error");
            }
        }

        // Accion para cancelar una reservacion
        [HttpGet]
        public ActionResult Cancelar(int idReservacion)
        {
            try
            {
                PersonaModel sesion = (PersonaModel)Session["usuario"];
                if (sesion == null)
                {
                    return View("PantallaAutenticacion");
                }
                GestionarReservacionesModel infoDeUnaReservacion = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    infoDeUnaReservacion = (from r in db.spMostrarReservacionPorUnUsuario(idReservacion)
                                            select new GestionarReservacionesModel
                                            {
                                                estado = r.estado,
                                                fechaSalida = r.fechaSalida
                                            }).FirstOrDefault();

                }
                if (infoDeUnaReservacion.estado == "I" || infoDeUnaReservacion.fechaSalida <= DateTime.Today)
                {
                    return RedirectToAction("Retornar", "Reservaciones");
                }
                if (infoDeUnaReservacion.fechaEntrada <= DateTime.Today && infoDeUnaReservacion.fechaSalida >= DateTime.Today)
                {
                    return RedirectToAction("Retornar", "Reservaciones");
                }
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    db.spCancelarReservacion(idReservacion, sesion.idPersona, DateTime.Now);
                }

                ViewBag.aviso = "Se ha cancelado con exito su reservación";
                return View("Mensaje");
            }
            catch
            {
                return View("Error");
            }
        }

        //Accion para mostrar todas las habitaciones
        [HttpGet]
        [VerificarSesionFilters]
        public ActionResult Habitaciones()
        {
            try
            {
                PersonaModel sesion = (PersonaModel)Session["usuario"];

                if (Session["usuario"] == null)
                {
                    return RedirectToAction("Autenticacion", "Reservaciones");
                }
                if (sesion.esEmpleado == false)
                {
                    return RedirectToAction("MisReservaciones", "Reservaciones");
                }

                List<HabitacionModel> listaHabitaciones = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    listaHabitaciones = (from h in db.spMostrarHabitaciones()
                                         select new HabitacionModel
                                         {
                                             idHabitacion = h.idHabitacion,
                                             nombreHotel = h.nombre,
                                             numeroHabitacion = h.numeroHabitacion,
                                             capacidadMaxima = h.capacidadMaxima,
                                             estado = h.estado
                                         }).ToList();
                }
                return View("ListaHabitaciones", listaHabitaciones);
            }

            catch
            {
                return View("_Error");
            }
        }

        //Accion para crear habitaciones
        [HttpGet]
        public ActionResult CrearHabitacion()
        {
            try
            {
                PersonaModel sesion = (PersonaModel)Session["usuario"];
                if (sesion == null)
                {
                    return View("PantallaAutenticacion");
                }

                //Consigo los datos para el DDL de los Hoteles
                List<GestionarReservacionesModel> listaHoteles = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    listaHoteles = (from h in db.spDropDownHotel()
                                    select new GestionarReservacionesModel
                                    {
                                        idHotel = h.idHotel,
                                        nombreHotel = h.nombre
                                    }).ToList();
                }

                ViewBag.hoteles = listaHoteles;
                return View("CrearHabitacion");
            }
            catch
            {
                return View("Error");
            }
        }

        //Accion post para crear habitaciones
        [HttpPost]
        public ActionResult CrearHabitacion(HabitacionModel habitacion)
        {
            try
            {
                PersonaModel sesion = (PersonaModel)Session["usuario"];
                if (sesion == null)
                {
                    return View("PantallaAutenticacion");
                }
                if (sesion.esEmpleado == false)
                {
                    return RedirectToAction("MisReservaciones", "Reservaciones");
                }

                //Consigo los datos para el DDL de los Hoteles
                List<GestionarReservacionesModel> listaHoteles = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    listaHoteles = (from h in db.spDropDownHotel()
                                    select new GestionarReservacionesModel
                                    {
                                        idHotel = h.idHotel,
                                        nombreHotel = h.nombre
                                    }).ToList();
                }
                ViewBag.hoteles = listaHoteles;

                if (!ModelState.IsValid)
                {

                    return View("CrearHabitacion", habitacion);
                }

                bool existeNumeroHabitacion = false;
                List<HabitacionModel> listaHabitaciones = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    listaHabitaciones = (from h in db.spMostrarHabitacionesPorHotel(habitacion.idHotel)
                                         select new HabitacionModel
                                         {
                                             numeroHabitacion = h.numeroHabitacion

                                         }).ToList();
                    foreach (var cuarto in listaHabitaciones)
                    {
                        if (habitacion.numeroHabitacion == cuarto.numeroHabitacion)
                        {
                            existeNumeroHabitacion = true;
                        }
                    }

                    if (existeNumeroHabitacion == false)
                    {
                        db.spInsertarHabitacion(habitacion.idHotel, habitacion.numeroHabitacion, habitacion.capacidadMaxima, habitacion.descripcion);
                        ViewBag.aviso = "Se ha creado una nueva habitación";
                        ViewBag.difenciador = "Habitacion";
                        return View("Mensaje");
                    }
                    else
                    {
                        ViewBag.aviso = "El número de habitación ya esta registrado en este hotel";
                        return View("CrearHabitacion");
                    }
                    
                }

            }
            catch
            {
                return View("Error");
            }
        }

        //Accion para jalas los datos a editar de las habitaciones
        [HttpGet]
        public ActionResult EditarHabitacion(int idHabitacion)
        {
            try
            {
                PersonaModel sesion = (PersonaModel)Session["usuario"];
                if (sesion == null)
                {
                    return View("PantallaAutenticacion");
                }
                if (sesion.esEmpleado == false)
                {
                    return RedirectToAction("MisReservaciones", "Reservaciones");
                }

                HabitacionModel habitacion = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {

                    //Aqui consigo los demas datos a llenar en el form
                    habitacion = (from h in db.spMostrarUnaHabitacion(idHabitacion)
                                  select new HabitacionModel
                                  {
                                      idHotel = h.idHotel,
                                      numeroHabitacion = h.numeroHabitacion,
                                      capacidadMaxima = h.capacidadMaxima,
                                      descripcion = h.descripcion,
                                      estado = h.estado,
                                      nombreHotel = h.nombre,
                                      idHabitacion = h.idHabitacion
                                  }).FirstOrDefault();


                }
                if (habitacion.estadoInterpretado == "Inactiva") 
                {
                    return RedirectToAction("Retornar", "Reservaciones");
                }


                return View("EditarHabitacion", habitacion);

 
            }
            catch
            {
                return View("Error");
            }
        }

        //Accion para editar habitaciones
        [HttpPost]
        public ActionResult EditarHabitacion(HabitacionModel habitacion)
        {
            try
            {
                PersonaModel sesion = (PersonaModel)Session["usuario"];
                if (sesion == null)
                {
                    return View("PantallaAutenticacion");
                }

                if (!ModelState.IsValid)
                {

                    return View("EditarHabitacion", habitacion);
                }

                //Edito la habitacion
                bool existeNumeroHabitacion = false;
                List<HabitacionModel> listaHabitaciones = null;
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    listaHabitaciones = (from h in db.spMostrarHabitacionesPorHotel(habitacion.idHotel)
                                         select new HabitacionModel
                                         {
                                             numeroHabitacion = h.numeroHabitacion

                                         }).ToList();
                    foreach (var cuarto in listaHabitaciones)
                    {
                        if (habitacion.numeroHabitacion == cuarto.numeroHabitacion)
                        {
                            existeNumeroHabitacion = true;
                        }
                    }
                    if (existeNumeroHabitacion == false)
                    {
                        db.spEditarHabitacion(habitacion.idHabitacion, habitacion.numeroHabitacion, habitacion.capacidadMaxima, habitacion.descripcion);
                        ViewBag.aviso = "Se ha editado la habitación";
                        ViewBag.difenciador = "Habitacion";
                        return View("Mensaje");
                    }
                    else
                    {
                        ViewBag.aviso = "El número de habitación ya esta registrado en este hotel";
                        return View("EditarHabitacion", habitacion);
                    }

                }

            }
            catch
            {
                return View("Error");
            }
        }

        //Accion para jalas los datos a editar de las habitaciones
        [HttpGet]
        public ActionResult Inactivar(int idHabitacion)
        {
            try
            {
                PersonaModel sesion = (PersonaModel)Session["usuario"];
                if (sesion == null)
                {
                    return View("PantallaAutenticacion");
                }
                using (PVI_ProyectoFinal db = new PVI_ProyectoFinal())
                {
                    db.spDesactivarHabitacion(idHabitacion);
                }

                ViewBag.aviso = "Se ha desactivado la habitación";
                ViewBag.difenciador = "Habitacion";
                return View("Mensaje");
            }
            catch
            {
                return View("Error");
            }
        }

        // Accion para cerrar sesion
        [HttpGet]
        public ActionResult Salir()
        {
            try
            {
                Session.RemoveAll();
                return RedirectToAction("Autenticacion", "Reservaciones");
            }
            catch
            {
                return View("Error");
            }
        }

    }
}