﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoFinalSistemaReservaciones.Models
{
    public class BitacoraModel
    {
        public int idBitacora { get; set; }

        public int idReservacion { get; set; }

        public int idPersona { get; set; }

        public string accionRealizada { get; set; }

        public DateTime fechaDeLaAccion { get; set; }

        public string nombreCompleto { get; set; }
    }
}