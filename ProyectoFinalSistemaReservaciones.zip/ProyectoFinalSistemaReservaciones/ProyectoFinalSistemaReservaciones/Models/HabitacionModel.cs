﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProyectoFinalSistemaReservaciones.Models
{
    public class HabitacionModel
    {
        public int idHabitacion { get; set; }

        [Required(ErrorMessage = "Campo Requerido")]
        public int idHotel { get; set; }

        public string nombreHotel { get; set; }

        [Required(ErrorMessage = "Campo Requerido")]
        [StringLength(10, ErrorMessage = "La longitud de este campo debe estar entre3 y 10 caractéres", MinimumLength = 3)]
        public string numeroHabitacion { get; set; }

        [Required(ErrorMessage = "Campo Requerido")]
        [StringLength(500, ErrorMessage = "La longitud de este campo debe estar entre 5 y 500 caractéres", MinimumLength = 5)]
        public string descripcion { get; set; }

        [Required(ErrorMessage = "Campo Requerido")]
        [Range(1, 8, ErrorMessage = "La capacidad es entre 1 y 8")]
        public int capacidadMaxima { get; set; }

        public string estado { get; set; }

        public string estadoInterpretado
        {
            get
            {
                switch (this.estado)
                {
                    case "A":
                        return "Activa";
                    case "I":
                        return "Inactiva";
                    default:
                        return "No hay categoría";
                }
            }
        }
    }
}