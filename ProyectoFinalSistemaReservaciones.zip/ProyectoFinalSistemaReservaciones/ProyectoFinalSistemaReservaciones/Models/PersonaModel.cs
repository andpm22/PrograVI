﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProyectoFinalSistemaReservaciones.Models
{
    public class PersonaModel
    {
        public int idPersona { get; set; }

        public string nombreCompleto { get; set; }

        [Required(ErrorMessage = "Correo requerido")]
        [StringLength(150, ErrorMessage = "La longitud de este campo debe estar entre 5 y 150 caracteres", MinimumLength = 5)]
        [Display(Name = "Correo")]
        [EmailAddress(ErrorMessage = "Su formato de correo es inválido")]
        public string email { get; set; }

        [Required(ErrorMessage = "La clave es requerida")]
        [Display(Name = "Contraseña")]
        [StringLength(150, ErrorMessage = "La longitud de este campo debe estar entre 1 y 150 caracteres", MinimumLength = 1)]
        public string clave { get; set; }

        public Boolean esEmpleado { get; set; }

        public string estado { get; set; }
    }
}