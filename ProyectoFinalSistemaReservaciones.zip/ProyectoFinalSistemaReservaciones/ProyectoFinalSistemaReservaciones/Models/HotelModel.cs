﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoFinalSistemaReservaciones.Models
{
    public class HotelModel
    {

        public int idHotel { get; set; }

        public string nombre { get; set; }

        public string direccion { get; set; }

        public decimal costoPorCadaAdulto { get; set; }

        public decimal costoPorCadaNinho { get; set; }
        
    }
}