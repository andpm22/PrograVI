﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ProyectoFinalSistemaReservaciones.Models
{
    public class GestionarReservacionesModel
    {
        //Clase para gestionar mis reservaciones

        public int idReservacion { get; set; }
        
        [Required(ErrorMessage = "Campo Requerido")]
        public int? idPersona { get; set; }

        public int idHabitacion { get; set; }

        public string nombreCompleto { get; set; }

        public string nombreHotel { get; set; }
        
        [Required(ErrorMessage = "Campo Requerido")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Fecha entrada")]
        public DateTime? fechaEntrada { get; set; }
        
        [Required(ErrorMessage = "Campo Requerido")]
        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MM-yyyy}" )]
        [Display(Name = "Fecha salida")]
        public DateTime? fechaSalida { get; set; }
        
        [Required(ErrorMessage = "Campo Requerido")]
        [Range(1,8, ErrorMessage = "Digite entre 1 a 8 adultos")]
        public int numeroAdultos { get; set; }
        
        [Required(ErrorMessage = "Campo Requerido")]
        public int numeroNinhos { get; set; }

        public int totalDiasReservacion { get; set; }

        public decimal costoPorCadaAdulto { get; set; }

        public decimal costoPorCadaNinho { get; set; }

        public decimal costoTotal { get; set; }

        public DateTime fechaCreacion { get; set; }

        public DateTime? fechaModificacion { get; set; }

        public string estado { get; set; }

        public Boolean esEmpleado { get; set; }

        [Required(ErrorMessage = "Campo Requerido")]
        public int? idHotel { get; set; }
        
        public string numeroHabitacion { get; set; }

        public int capacidadHabitacion { get; set; }

        public string estadosTraducidos 
        {
            get
            {
                if (this.estado == "I")
                {
                    return "Cancelada";
                }
                if (this.estado == "A" && this.fechaSalida < DateTime.Now)
                {
                    return  "Finalizada";
                }
                if (this.estado == "A" && this.fechaEntrada <= DateTime.Today)
                {
                    return "En proceso";
                }
                if (this.estado == "A" && this.fechaEntrada > DateTime.Now && this.fechaSalida > DateTime.Now)
                {
                    return "En espera";
                }
                else
                {
                    return "Error";
                }
            }
        
        }




    }
}