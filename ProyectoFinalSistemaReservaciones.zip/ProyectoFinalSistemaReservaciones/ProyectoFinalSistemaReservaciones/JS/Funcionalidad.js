﻿function alertaCancelar() {
    var respuesta = false;
    if (confirm("¿ Esta seguro que desea cancelar su reservación ?")) {
        respuesta = true;
    }
    else {
        respuesta = false;
    }
}